# LLM Architecture v9 — Training Pilot

This standalone package contains the executable miniature CPU reference trainer, a streaming Hugging Face dataset exporter, split-bundle verification, automated tests and recorded evidence. It does not contain a production-scale LLM or claim full online-corpus training.

## Reproduce the miniature CPU pilot

Python 3.13.5 and PyTorch 2.10.0+cpu were used for the recorded run. Install:

```bash
python -m pip install -r pilot_requirements.txt
```

Run all three profiles for both seeds:

```bash
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python train_pilot.py
```

Defaults: P0, P1 and P1-LA; seeds `20261118` and `20261119`; 500 steps; context 32; batch 4. Results and checkpoints are written under `results/`.

Verify the supplied evidence and the split-exporter tests:

```bash
python verify_pilot_artifacts.py
python -m unittest -v test_dataset_pipeline.py
```

The evidence verifier checks six full model/seed runs, checkpoint digests, matched baselines, causal/state-reset/gradient/finite-value invariants, repeatability, and a later source-identified repeat with run-time SHA-256 values for the trainer, exporter and dataset manifest. It does not infer the source-byte identity of the original six runs.

## Full online Hugging Face dataset path (not executed here)

Install the data library:

```bash
python -m pip install -r dataset_requirements.txt
```

Review the dataset's source, actual license and permitted uses first. Select an immutable 40-character commit SHA, then export official splits. Example:

```bash
python prepare_hf_dataset.py --dataset Salesforce/wikitext --config wikitext-2-raw-v1 --revision <40-character-commit-sha> --streaming --output-dir data/wikitext2
```

This leaves rights pending. Following human review, include `--rights-reviewed`, a truthful `--license-statement`, and each explicitly permitted `--allowed-use` separately. Do not self-certify legal rights.

Train from full verified splits only after review:

```bash
PILOT_DATA_DIR="$PWD/data/wikitext2" OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python train_pilot.py
```

The trainer verifies the external manifest checksum, split SHA-256 values, byte/character counts, immutable revision identity, distinct split files and non-identical split contents. It rejects rights-pending data by default. `PILOT_ALLOW_UNREVIEWED_DATA=1` is only for an explicit exploratory local smoke test; never use it to approve production/commercial training.

## Findings and evidence boundary

The six completed neural runs trained on a locally materialized **29,926-byte excerpt** retrieved from the online Tiny Shakespeare GitHub source, not the full 1.11 MB corpus or official Hugging Face splits. On the tiny character task, P1 improved over P0 by 1.07% mean test NLL and 1.26 top-1 points, but took 3.73x longer to train and had 2.87x lower naive CPU inference throughput. A smoothed bigram model beat every neural candidate. Outputs remained malformed character fragments.

The full remote dataset-exporter path was not executed: outbound network access failed and Hugging Face Jobs returned HTTP 402 Payment Required; no paid remote job was launched. The source transcription rights status is pending. Thus this establishes a miniature trainability signal only—not practical usefulness, general LLM quality, or production hardware performance.

See `TRAINING_PILOT_REPORT_v9.md` for detailed methods, results, source provenance, limitations and next experiments.
