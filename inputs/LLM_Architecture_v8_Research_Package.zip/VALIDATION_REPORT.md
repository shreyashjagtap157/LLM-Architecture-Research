# Validation Report — Architecture v6

**Date:** 17 November 2026  
**Scope:** static package/document validation only.

## Results

| Check | Result |
|---|---:|
| Specification lines | 1,476 |
| Specification words | 18,984 |
| Specification bytes | 146,155 |
| Bibliography entries | 86 |
| References used | 86 |
| Undefined references | 0 |
| Unused references | 0 |
| Duplicate main section numbers | 0 |
| Duplicate numbered subsections | 0 |
| Duplicate heading text | 0 |
| Mermaid diagrams | 1 |
| Duplicate Mermaid node IDs | 0 |
| YAML files parsed | 4/4 |
| Markdown/TXT equality | PASS |
| Audit Markdown/TXT equality | PASS |
| Original idea ZIP integrity | PASS |

## Detailed checks

- All bibliography entries R1–R86 are checked against in-text citations.
- Code-fence pairing and Mermaid node IDs are checked statically.
- YAML files are parsed with PyYAML.
- The original 11-member idea archive is tested for ZIP corruption.
- v6 Markdown and TXT exports are byte-identical.

## Execution environment and limitations

- PyTorch: `2.10.0+cpu`
- CUDA available: `False`
- CUDA devices: `0`
- Model training: **not performed**
- GPU kernel validation/performance: **not performed**
- Model benchmark runs: **not performed**

The static report does not validate numerical correctness of a trained model, kernel correctness, convergence, model quality or any claimed speedup. These remain blocked on target hardware, data, model scale and compute budget.

## Failures / warnings

- Undefined references: `[]`
- Unused references: `[]`
- Duplicate main-section numbers: `[]`
- Duplicate subsection numbers: `[]`
- Duplicate headings: `[]`
- Duplicate Mermaid node IDs: `[]`
