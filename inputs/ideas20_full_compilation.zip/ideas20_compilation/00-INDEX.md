# /IDEAS20 Compilation — Full Local Archive

Everything requested and provided across this conversation, consolidated for offline use. 160 ideas total across 8 batches, plus the Sentinel-specific mapping/descriptions and the full SOTA LLM architecture (v2, with upgrade paths).

| File | Contents |
|---|---|
| `01-computer-fields-ideas.md` | 20 ideas — uncharted computer science product ideas, general CS fields |
| `02-foundational-computing-ideas.md` | 20 ideas — OS/kernel, memory, filesystem, networking, compiler foundations |
| `03-ai-llm-agentic-ideas.md` | 20 ideas — AI/LLM software, agentic CLIs, agent architecture |
| `04-llm-architecture-internals-ideas.md` | 20 ideas — attention mechanics, interpretability, inference efficiency, sampling |
| `05-llm-efficiency-moe-memory-ideas.md` | 20 ideas — parameter reduction, MoE architecture, training speed, KV memory |
| `06-llm-inference-speed-ideas.md` | 20 ideas — inference speed only (attention compute, speculative decoding, KV cache, batching, decode algorithms) |
| `07-sentinel-mapped-topics-with-descriptions.md` | 20 of the above ideas, mapped specifically to the Sentinel agentic CLI architecture, each with full description (what it is / in Sentinel / globally) |
| `08-reasoning-cycling-fix-ideas.md` | 20 ideas — eliminating redundant LLM reasoning loops, architecture for efficient thinking |
| `09-sota-llm-architecture-v2.md` | The full synthesized SOTA LLM architecture document: 5 pillars + cross-cutting uncertainty bus, each tagged [PROVEN] / [PROVEN MECHANISM, NEW APPLICATION] / [PROPOSED] with training recipes, costs, and honest limits |

All ideas are drawn only from what was generated earlier in this conversation — nothing new has been added here beyond organizing it for local use.
