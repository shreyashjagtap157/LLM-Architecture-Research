# /IDEAS20 — AI/LLM & Agents, Software Only

## Formal Foundations for LLMs

1. **Prompt Algebra** — A formal algebraic system for prompts, with laws (commutativity, identity, composition) and provable equivalences. Optimize prompts as algebraic expressions, not by gut feel.

2. **Effect-Typed LLM Pipelines** — LLM calls tagged with computational effects (IO, state mutation, tool invocation) enforced by a type system. Invalid pipeline compositions are compile-time errors.

3. **Composable Prompt Type System** — Prompts as typed values, not strings. Compose with type-safe operators; prompt type errors caught before any API call.

4. **Context-Sensitive Grammar-Constrained Generation** — Beyond JSON mode: constrain LLM output token-by-token to any formal grammar including context-sensitive ones. Buildable over llama.cpp + custom sampler.

5. **Causal Output Attribution** — Map which input tokens causally caused which output tokens — not attention weights (correlational) but actual causal analysis via counterfactual interventions.

## Agent Architecture

6. **Session-Typed Agent Protocols** — Agent-to-agent communication described as session types; the interaction protocol is statically enforced.

7. **Process Algebra Agent Specification** — Describe agent behavior in CSP/CCS, formally verify with SPIN before deployment. Not prompt engineering — actual behavioral specification.

8. **Capability-Native Agent Permissions** — Agents hold unforgeable capability tokens for what they're allowed to do, enforced by the runtime, not system-prompt instructions the LLM can be talked out of.

9. **Recursive Symbolic Self-Modeling Agent** — An agent maintaining a formal symbolic model of its own capabilities, state, and limitations, updated through interaction. Pure logic + inference engine (Soufflé/Datalog).

10. **Monotonic Agent Memory** — Agent memory implemented as a CRDT lattice — can only grow, never corrupt, merge-safe across distributed agents.

## Agentic CLI & Developer Tooling

11. **Deterministic Agent Replay** — Record every LLM call, tool call, and state transition an agent makes; replay it identically from cache.

12. **Agentic Execution Diff** — Diff two agent runs semantically — which decision points diverged, why, and what downstream effect it had.

13. **Agent Execution Budget Primitive** — First-class token, tool-call, and wall-time budgets for agents, enforced by the runtime with defined graceful-degradation policy.

14. **Intent-Typed Agent Checkpointing** — Checkpoint agent state carrying its semantic intent, not just variable state. Resume from any checkpoint with full goal context preserved.

15. **Semantic Agent Versioning** — Version agents by behavioral semantics, not code version — two agents are the same version if behaviorally equivalent on a test suite.

## Multi-Model & Advanced

16. **Multi-LLM Semantic Consensus** — Run the same task across multiple LLMs, extract consensus on the semantic parse of outputs, not string voting. Disagreement surfaces ambiguity.

17. **Adversarial Context Minimization** — Given a prompt + response, find the minimal context subset producing semantically equivalent output. Formal minimization via bisection search.

18. **Temporal Causal Context Compression** — Organize context windows by causal importance over time, not recency. A formal retention function, not a sliding window.

19. **Zero-Knowledge Agent Audit** — Prove an agent executed correctly and within policy without revealing its full execution trace. Built on ZK proof libraries (Bellman) + execution commitment scheme.

20. **LLM-Native Formal Spec Extractor** — Use LLMs to extract formal specs (TLA+, Alloy, Lean) from natural-language requirements, then verify code against those specs with existing model checkers.
