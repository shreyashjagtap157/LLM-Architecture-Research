# /IDEAS20 — Foundational Computing, Current-Tech Implementable

## Memory & Storage Primitives

1. **Intent-Typed Memory Allocator** — Memory regions tagged with semantic intent at allocation; the allocator enforces access patterns matching that intent. Pure allocator design in Rust.

2. **Temporal Memory Model** — RAM abstraction where every write is timestamped at the hardware-register level — any address queryable at any past logical time. Built on existing MMU + append-only backing.

3. **Ownership-Native Heap** — A heap where ownership semantics are enforced by the allocator itself, not the language. Language-agnostic; free/use-after-free impossible at the allocator boundary.

## Compute & Execution Model

4. **Lazy CPU Instruction Scheduler** — A userspace binary rewriter converting eager instruction sequences into lazy ones — instructions execute only when their output is demanded.

5. **Causal Execution Threads** — Threads carrying a causal certificate — which prior computation caused this thread to spawn — letting the OS scheduler prioritize by causal depth.

6. **Reversible Computation Runtime** — A runtime where any function is reversible by default — execution state checkpointed as inverse operations, not full snapshots. Based on Landauer/Bennett reversible logic.

## Filesystems & I/O

7. **Semantic Filesystem** — Files stored not by path but by what they are — their structure, schema, type. Queried like a database, no directories. FUSE + SQLite + tree-sitter.

8. **Causality-Linked File Provenance** — Every file knows what caused it — which process, input file, syscall chain. A causal DAG embedded in filesystem metadata. FUSE-implementable.

9. **Demand-Paged Virtual Filesystem** — A FUSE filesystem where file contents are computed lazily on read — defined as pure functions of other files. Spreadsheet model applied to filesystems.

## Networking Foundations

10. **Type-Safe Packet Schemas** — Network packets described as types — malformed packets unrepresentable. Serializer/deserializer derived automatically. Buildable in Rust.

11. **Causal Network Ordering Primitive** — A userspace library giving any two machines a shared causal clock without NTP, using only message-passing. Vector clocks as a zero-dependency drop-in.

12. **Session-Typed Socket Layer** — Sockets where the conversation protocol is encoded as a type — the compiler rejects programs sending in wrong order or forgetting to close.

## OS & Kernel Primitives

13. **Capability-Native Process Model** — Every syscall requires an unforgeable capability token, not Unix permissions. Implementable in userspace via seccomp + a capability broker.

14. **Algebraic Process Scheduler** — Processes described by algebraic laws (commutativity, associativity of execution); the scheduler exploits these to reorder safely. Formally verifiable.

15. **Deterministic Syscall Replay** — Record every syscall a process makes; replay it identically on any machine, any time. `strace` + a deterministic replay engine.

## Compiler & Language Foundations

16. **Separation Logic Native IR** — An IR where every value carries a separation logic frame — the compiler proves memory disjointness as a first-class IR pass, not post-hoc analysis. Buildable on LLVM IR.

17. **Effect-Typed Linker** — A linker tracking computational effects (IO, allocation, exceptions) across compilation units, flagging effect leaks at link time.

18. **Structural Binary Diffing** — Diff two compiled binaries at the semantic IR level, not byte level. Reverse engineer both to IR, diff the IR graphs. Built on Ghidra's free decompiler.

## Data & Logic Foundations

19. **Constraint-Native Data Model** — A data store where constraints are first-class citizens stored with the data, not enforced by application logic or DB triggers.

20. **Monotonic Computation Primitive** — A general-purpose library primitive where computations only grow — results are monotonically accumulating lattice values. Based on CRDT + lattice theory.
