# /IDEAS20 — Uncharted Computer Science Product Ideas

All implementable with free/open tooling: Rust, tree-sitter, SQLite, Soufflé, Lean 4, Automerge, SPIN, Python, TypeScript.

## Tier 1 — Immediately Buildable, High Impact

1. **Compiler Error Semantic Diffing** — A tool that diffs *why* an error appeared between two commits — the semantic cause chain, not the code diff. Rust's borrow checker errors are a perfect fit. Buildable with tree-sitter + local LLM.

2. **Intent-Preserving Code Refactor Ledger** — A git-adjacent system recording developer intent alongside commits — queryable later as "why was this decision made?" Structured semantic reasoning graphs, not comments. SQLite + AST parsing.

3. **Deterministic Fuzzing via Execution Fingerprinting** — Instead of random input fuzzing, fingerprint the execution shape of a function and generate inputs that maximally diverge from known shapes. Pure symbolic + graph theory, no ML. Buildable in Rust.

4. **Silent Dependency Drift Detector** — Detects when a dependency *behaves differently* than when first integrated (not version drift — behavioral drift) by replaying historical call traces against the new version.

5. **Grammar-Native Config Language** — A config format where the schema *is* the grammar. Invalid configs are syntactically impossible. Buildable as a PEG parser in Rust.

## Tier 2 — Novel Problem Space, Moderate Build Complexity

6. **Execution Budget Language Primitive** — A language-level construct letting you annotate functions with computational cost ceilings enforced at runtime, not profiled after. E.g. `#[budget(10ms, 2MB)]`.

7. **Causality-Aware Logging** — Logs recording not just *what* happened but the causal graph of *why* — which prior log event caused this one. Pure instrumentation + graph construction, queryable like a database.

8. **Type-System-Enforced API Versioning** — API versions encoded as type parameters — calling a deprecated endpoint is a compile error, not a runtime 404. Buildable with Rust generics or TypeScript's type system.

9. **Semantic Diff for Databases** — Detects when a migration technically applies but semantically breaks a business invariant (e.g. a NOT NULL column that was logically always null for a user class). Uses constraint solving.

10. **Offline-First Collaborative CRDT Notebook** — A notebook where every cell is a CRDT — merge two people's execution histories without conflicts, including output merging. Automerge + local execution engine.

## Tier 3 — Paradigm-Level, Longer Runway

11. **Proof-Carrying Build Artifacts** — Build outputs carrying machine-checkable proofs of properties (memory safety, bounded-input termination) alongside the binary. Lean 4 + custom linker section.

12. **Reactive Type Inference** — A type system where types propagate reactively — changing a type upstream automatically resolves or flags downstream implications, live, in the editor.

13. **Execution-Time Ontology (No ML Required)** — Program behavior described as logical axioms + rules; the "AI" is a forward-chaining inference engine. Deterministic, auditable, zero training. Buildable with Datalog (Soufflé).

14. **Morphic Version Control** — VCS where the unit of change is a semantic transformation (rename, extract, inline, reorder), not a line or file. Merges become transformation composition.

15. **Process Algebra-Based Microservice Orchestrator** — Services described in CSP/CCS — interaction protocols formally verified before deployment. Buildable with existing model checkers (SPIN).

## Tier 4 — Sleeper Hits

16. **Hardware-Topology-Aware Task Scheduler (userspace)** — Reads your CPU's actual cache topology and NUMA layout, schedules your app's threads accordingly — not the OS's generic scheduler.

17. **Symbolic Execution as a Test Generator, Not a Verifier** — Tools like KLEE verify; this generates beautiful, readable unit tests from symbolic paths — developer-facing, not researcher-facing.

18. **Immutable Append-Only Config Store with Time Travel** — Every config change ever made is stored, queryable, replayable. Local-first, SQLite-backed, with temporal queries.

19. **Polyglot AST Bridge** — A universal AST interchange format — write a lint rule once, run it across Python, Rust, TypeScript, Go. Buildable with tree-sitter.

20. **Probabilistic Invariant Mining (No ML)** — Observe a running program, extract statistical invariants (à la Daikon), encode them as falsifiable runtime assertions hardening over time as observations confirm them.
