# Sentinel Project — Mapped Topics with Full Descriptions

20 ideas from the batches above, mapped to specific components of the Sentinel agentic CLI platform (13-crate Rust workspace, 4-tier memory engine, multi-provider LLM layer, hierarchical state machine agent engine, WASM plugin system, MPSC event bus).

---

## 1. Causal KV Cache Eviction → Episodic/Semantic Tier Eviction Policy

**What it is:** Score each KV cache entry by counterfactual causal influence — ablate an entry, measure output distribution shift via KL divergence, use that delta as the retention score — instead of recency (sliding window) or attention magnitude (H2O).

**In Sentinel:** The Episodic tier (SQLite + tantivy BM25) and Semantic tier (GraphRAG + RRF) both face eviction decisions at memory bounds. Causal eviction means episodic memories that causally influenced recent agent decisions are retained; semantically stored entities contributing zero to recent retrievals are evicted first.

**Globally:** Any LLM system with finite context/memory benefits from principled eviction; current shipped systems (StreamingLLM, H2O) are magnitude heuristics, not causally grounded.

---

## 2. Monotonic Agent Memory (CRDT) → Working Memory Merge Resolution

**What it is:** Agent working memory as a CRDT join-semilattice — any two states merge into a valid combined state with no conflicts, no locks, no coordinator.

**In Sentinel:** When the DAG planner spawns parallel sub-tasks via Rayon-parallel paths or concurrent tool calls on the MPSC event bus, multiple writers update working memory simultaneously. CRDT semantics let parallel tool executions write independently and merge deterministically, eliminating write contention.

**Globally:** Distributed agent systems, multi-agent collaboration, offline-first apps — any system where multiple writers share state without a central coordinator.

---

## 3. Temporal Causal Context Compression → Context Manager Before LLM Dispatch

**What it is:** Organize context by causal importance over time, not recency. Chunks get a causal retention score; causally critical old chunks (task spec) are kept, causally inert recent chunks (summarized intermediate tool output) are dropped.

**In Sentinel:** Before dispatching to any provider (Claude Opus 4, OpenAI Responses API, Gemini 2.5, Ollama), the context manager fits conversation history + memory retrievals + tool history into token limits. This retains the task spec and critical tool results regardless of age, dropping only causally inert intermediate steps.

**Globally:** Every production LLM app hits context limits in long sessions; this is a principled alternative to blunt sliding windows or lossy summarization.

---

## 4. Adversarial Context Minimization → Pre-Call Context Window Optimizer

**What it is:** Bisection search finding the minimal context subset producing semantically equivalent output — aggressively removing context and testing semantic equivalence via embedding similarity.

**In Sentinel:** Run before each provider call over assembled context (tool history, memory retrievals, conversation turns). Reduces per-call token cost and extends effective session length, especially valuable for the highest-cost provider (Claude Opus 4).

**Globally:** Any cost- or latency-sensitive LLM application; a principled automatic alternative to manual prompt engineering.

---

## 5. Semantic Context Fixpoint Compressor → Embedding Queue Compression

**What it is:** Iteratively compress context until further compression changes model output (measured by semantic similarity) — a formal convergence criterion, not a heuristic summarizer.

**In Sentinel:** Applied to the workspace indexing pipeline's embedding queue (notify debouncer → tree-sitter → tantivy → embedding queue). Merges semantically redundant chunks before they're embedded into the semantic GraphRAG tier, collapsing near-duplicates from incremental saves.

**Globally:** RAG systems and embedding-based retrieval accumulate redundant representations over time; this is a principled dedup layer.

---

## 6. Context Topology Reorderer → Pre-Call Token Reordering Layer

**What it is:** Reorder context tokens before encoding based on a mutual-dependency graph, minimizing distance between mutually dependent chunks within the attention window. Model-agnostic, no retraining.

**In Sentinel:** Before provider dispatch, reorder system prompt, memory retrievals, tool history, and conversation turns so dependent components are co-located — improving attention efficiency especially for Ollama models with narrow effective context.

**Globally:** All transformer-based LLMs; attention efficiency degrades when mutually dependent tokens are far apart in sequence.

---

## 7. Hierarchical Context Encoding at Multi-Resolution → Semantic Memory Multi-Resolution Encoding

**What it is:** Encode context at token, phrase, and paragraph granularity simultaneously via three lightweight projection layers; attention operates across all three resolutions.

**In Sentinel:** Added to GraphRAG nodes — each node gets token-level, phrase-level, and paragraph-level representation vectors. RRF fusion across resolutions dramatically improves recall for queries at different abstraction levels than the stored content.

**Globally:** RAG systems and long-document understanding — single-granularity embeddings systematically fail for cross-scale queries.

---

## 8. Semantic KV Clustering with Centroid Retrieval → Semantic Tier Retrieval

**What it is:** Cluster KV pairs online by semantic similarity (FAISS ANN index); retrieve centroid-approximated KV with bounded error instead of searching the full store.

**In Sentinel:** Applied to semantic tier retrieval over GraphRAG nodes. Retrieval first queries cluster centroids, then members of matching clusters, reducing retrieval latency from O(n) to O(k) as the graph grows over long sessions.

**Globally:** Any large-scale KV cache or embedding retrieval system; production vector databases already use this principle.

---

## 9. Multi-LLM Semantic Consensus → ClassifierBased/Cascading Router Enhancement

**What it is:** Run the same task across multiple LLMs in parallel, compute agreement on semantic parse of outputs (not string voting). Agreement validates cheaply; disagreement surfaces genuine ambiguity.

**In Sentinel:** Added to the multi-provider LLM layer's ClassifierBased/Cascading/ConfigOrder routing. For uncertain tasks, dispatch to 2-3 providers in parallel; high consensus returns the cheapest provider's output, low consensus cascades to the highest-capability model.

**Globally:** Any production LLM app requiring reliability guarantees beyond single-model outputs of unknown error rate.

---

## 10. Entropy-Adaptive Temperature Scheduler → Per-Provider Sampling Config Layer

**What it is:** Compute per-token output entropy dynamically; high-entropy positions get higher temperature (exploration), low-entropy positions get lower temperature (commitment).

**In Sentinel:** Per-provider, per-task-type temperature profiles replace a single static temperature value — creative tasks get elevated temperature at high-entropy prefixes, structured tool-call generation gets near-zero temperature at low-entropy structure.

**Globally:** All LLM inference systems; fixed temperature is a blunt instrument applied uniformly to certain and uncertain positions alike.

---

## 11. Confidence-Gated Multi-Step Greedy Commit → Ollama Local Sampler

**What it is:** When output entropy drops below threshold for N consecutive tokens, switch to greedy decoding (argmax), bypassing sampling overhead; resume sampled decoding when entropy rises.

**In Sentinel:** Applied to Ollama local inference, the performance bottleneck in local-model mode. Reduces per-token sampling compute during high-confidence runs common in structured output generation (JSON tool calls, file paths, code syntax).

**Globally:** Any local LLM inference system where per-token compute matters; structured output has long high-confidence runs where sampling adds overhead without benefit.

---

## 12. Decode Path Prefix-Tree Prewarming → Procedural Memory Tier Prefix Structure

**What it is:** A prefix tree of historically common generation sequences; prewarm KV cache along the highest-probability path before generation reaches those positions.

**In Sentinel:** The Procedural memory tier's frequency/recency-scored action sequences are structurally prefix trees (e.g. read_file → analyze → write_file). Encoding this explicitly enables prewarming the LLM KV cache along high-frequency procedural paths before execution.

**Globally:** Production LLM serving for high-repetition workloads — code assistants, agent frameworks, customer support bots.

---

## 13. Session-Typed Agent Protocols → Typed Agent State Machine Transitions

**What it is:** Session types encode the valid sequence of state transitions in the Rust type system; invalid transitions produce compile-time errors, not runtime panics.

**In Sentinel:** Applied to the hierarchical state machine (Idle→Processing→Recovering with nested Processing/Validation sub-states). Encoded as Rust typestate pattern; invalid transitions become compile-time errors, eliminating a class of runtime agent state bugs.

**Globally:** Any stateful agent system, protocol implementation, or distributed system needing guaranteed message ordering and state validity.

---

## 14. Capability-Native Agent Permissions → WASM Plugin Capability Token Enforcement

**What it is:** Unforgeable capability tokens issued at initialization; the runtime enforces scope, not a policy lookup that can be bypassed.

**In Sentinel:** Applied to the WASM Component Model plugin system (wasmtime v46, WIT interfaces). Each WIT interface call requires a matching capability token; wasmtime's linear memory isolation makes tokens unforgeable across component boundaries.

**Globally:** Security-critical plugin systems and sandboxed execution environments; eliminates ambient authority / privilege escalation structurally.

---

## 15. Intent-Typed Agent Checkpointing → State Machine Checkpoint Carrier

**What it is:** Checkpoints carry a typed semantic goal representation, not just execution state — the agent's current goal, sub-goals, and causal chain, not merely variable values.

**In Sentinel:** Each checkpoint in SQLite carries a typed goal representation mirroring the DAG plan node types. On crash recovery, the agent reconstructs planning context, not just execution position, enabling coherent continuation for long-running multi-hour tasks.

**Globally:** Long-running agent systems — autonomous coding agents, research agents, workflow automation.

---

## 16. Deterministic Agent Replay → Event Bus Session Replay Protocol

**What it is:** Record every LLM call (input hash → output), tool call, and state transition; replay serves cached responses for byte-identical re-execution.

**In Sentinel:** Extends the existing MPSC event bus session replay protocol with LLM call recording (content hash → cached response), enabling fully deterministic re-execution of any past session for bug reproduction, regression testing, and behavioral diffing across model versions.

**Globally:** Agent debugging and regression testing — the same tooling model as rr (record-and-replay debugger) applied to LLM agents.

---

## 17. Agentic Execution Diff → Session Replay Causal Divergence Analysis

**What it is:** Given two session execution graphs, compute the exact causal decision point where they diverged, via structural DAG comparison, not output diffing.

**In Sentinel:** Between two deterministic replays (different provider or temperature), identifies the exact LLM call or tool result that triggered a divergent DAG planning path, surfaced via OTel structured JSON logs as causal diff spans.

**Globally:** Agent evaluation, model comparison, and CI/CD for agent systems — identifying where and why behavior diverged, not just that it did.

---

## 18. Agent Execution Budget Primitive → Token/Tool-Call Budget Enforcement Layer

**What it is:** First-class runtime enforcement of per-task token, tool-call, and wall-time budgets, with defined degradation policy when exceeded — not prompt instructions.

**In Sentinel:** Per-task budgets intercept every MPSC event bus dispatch for LLM and tool calls, tracking consumption and applying the declared policy (ConfigOrder failover, graceful summarization halt, or hard abort with checkpoint) when hit.

**Globally:** Production agentic systems where runaway tasks consume unbounded resources — the fundamental resource governance primitive missing from current agent frameworks.

---

## 19. Recursive Symbolic Self-Modeling Agent → Datalog Self-Model in Agent Engine

**What it is:** A formal symbolic model of the agent's own capabilities, state, and past performance, encoded as Datalog facts/rules (Soufflé) — planning queries answered via pure logical inference where possible.

**In Sentinel:** Encodes available WASM plugin capabilities and past tool success/failure rates as facts. For well-understood task patterns the Procedural tier has seen frequently, planning queries resolve via inference with zero LLM calls; LLM calls reserved for genuinely novel problems.

**Globally:** Any agent system where LLM planning calls are expensive — routing predictable decisions to a zero-cost inference engine cuts operational cost at volume.

---

## 20. Causal Output Attribution → Tool Call Causality Tracing via OTel Spans

**What it is:** Counterfactual causal analysis mapping which input context causally caused which output tokens/decisions — empirically verified by intervention, not attention weights.

**In Sentinel:** Adds causal edges between OTel spans — which memory retrieval caused which LLM planning decision, which tool result caused which subsequent invocation — producing a queryable causal audit trail from structured JSON logs.

**Globally:** Agent accountability and safety auditing — the technical foundation for auditable, explainable agent behavior as agents take consequential actions.
