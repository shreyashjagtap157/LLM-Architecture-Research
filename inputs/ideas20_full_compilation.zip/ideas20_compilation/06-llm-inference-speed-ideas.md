# /IDEAS20 — LLM Inference Speed Only

All implementable: PyTorch, HuggingFace, llama.cpp, Triton, FAISS.

## Attention Computation

1. **Attention Pattern Memoization Cache** — Cache full attention weight matrices for recurring input patterns, detected via fast fingerprinting. Exact reuse on fingerprint match.

2. **Per-Head Adaptive Dropping via Proxy Metric** — A cheap residual-output-norm proxy per head; drop heads whose proxy predicts near-zero contribution. Zero fine-tuning needed.

3. **LSH-Based Inference-Time Attention Sparsification** — Bucket queries/keys via locality-sensitive hashing; compute attention only within matching buckets, at inference, on any trained model.

4. **Semantic Tiling with Mutual Information Scoring** — Tile Flash Attention by mutual-information-scored token groups rather than fixed block size.

## Speculative Decoding Extensions

5. **Logit-Compressed Speculative Verification** — Compress both draft and target logits to top-k before verification comparison, 10-50x compute reduction.

6. **Asynchronous Dual-Phase Speculative Decoding** — Start drafting tokens N+1..N+k while verification of N..N+k is still in flight; fully parallelize draft and verify.

7. **Speculative Ensemble Micro-Drafting** — Run 3-5 tiny parallel drafters, take token-level consensus, send a single consensus sequence for one-pass verification.

8. **Decode Path Prefix-Tree Prewarming** — Maintain a prefix tree of historically common generation paths; prewarm KV cache for the highest-probability path before generation reaches it.

## KV Cache

9. **KV Delta Compression Across Layers** — Store full KV only at layer 0; store aggressively quantized deltas at subsequent layers, exploiting cross-layer correlation.

10. **Zero-Copy KV Offload with Predictive Prefetching** — Offload KV to CPU DRAM; a tiny sequence model predicts and prefetches needed entries ahead of decode steps.

11. **Per-Token Dynamic Precision KV Allocation** — fp16 for high-causal-influence KV entries, int4 for low-influence ones, within the same forward pass.

## Batching & Scheduling

12. **Batch Semantic Regrouping for Kernel Locality** — Dynamically regroup sequences by semantic similarity of residual-stream state during continuous batching.

13. **Prefill-Decode Phase Splitter with Predictive Block Pre-allocation** — A tiny regressor on prefill activations predicts decode length; pre-allocate exact KV blocks before decode begins.

14. **Decode Compute Recycling for Stable Token Regions** — Detect heads producing near-identical outputs for unchanged multi-turn tokens; recycle cached head outputs.

## Early Exit & Skipping

15. **Residual Stream Confidence Early Exit Gate** — A 2-parameter binary classifier per layer predicting whether the output token is already determined; exit the stack early.

16. **Learned Sparse Attention Mask Pre-computation** — A lightweight offline predictor maps input tokens to binary sparse attention masks applied before the full kernel.

## Memory & Compute Layout

17. **Inference-Time Neuron Cluster Gating** — Cluster MLP neurons offline by activation co-occurrence; activate entire clusters via a single gate decision.

18. **Token Merging at Language Inference** — Apply vision ToMe-style token merging to language model inference, shrinking effective sequence length by merging redundant tokens.

## Decode Algorithm

19. **Grammar-Constrained Pre-Softmax Token Elimination** — Eliminate logically impossible next tokens before the final linear projection and softmax, not post-logit masking.

20. **Confidence-Gated Multi-Step Greedy Commit** — Commit to greedy decoding for N consecutive low-entropy steps, bypassing sampling overhead entirely; switch back when entropy rises.
